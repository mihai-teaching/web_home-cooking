// ======================================================
// js / scripts.js
// ======================================================

// Fetch Data
// ======================================================

var url = "https://mihai-teaching.github.io/web_home-cooking/assets/aunt.json";
var data = null;

$.ajax({
  url: url,
  type: "GET",
  contentType: "application/json; charset=utf-8",
  dataType: "json"
})
  .done(function(result) {
    data = result;
  })
  .catch(function() {
    console.error("ERROR IN AJAX REQUEST");
  });

// When document is ready
// ======================================================

/**
 * Execute all my functions.
 */
$(document).ready(function() {
  updateDocumentTitle();
  // function2()...
  // function3()...
  // function4()...
  // etc.
});

// My functions
// ======================================================

/**
 * Update the document's title by using the provided data
 * from my aunt.
 */
var updateDocumentTitle = function() {
  // Some code...
};
